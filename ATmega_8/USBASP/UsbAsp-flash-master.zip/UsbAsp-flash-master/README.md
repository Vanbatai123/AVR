# UsbAsp-flash
Альтернативная прошивка  и программа для UsbAsp позволяющая программировать флеш память по протоколам SPI, I2C, MicroWire.
Обсуждение на форуме easyelectronics.ru http://forum.easyelectronics.ru/viewtopic.php?f=17&t=10947

Alternative firmware and UsbAsp program allow you to program flash memory on the protocols spi, I2C, MicroWire.
Discussion on the forum easyelectronics.ru http://forum.easyelectronics.ru/viewtopic.php?f=17&t=10947
