/*
 * LCD1602.c
 *
 * Created: 8/31/2018 2:06:15 PM
 *  Author: ASUS PC
 */ 

#include "../include.h"
#include "LCD1602.h"

char Read2Nib()
{
	char HNib, LNib;
	LCD1602_PORT|=0xF0;

	setb(LCD1602_PORT, LCD1602_PIN_EN); //enable
	LCD1602_DDR &=0x0F; //set 4 bits cao cua PORT DATA lam input
	HNib=LCD1602_PIN & 0xF0;
	clrb(LCD1602_PORT, LCD1602_PIN_EN); //disable

	setb(LCD1602_PORT,LCD1602_PIN_EN); //enable
	LNib = LCD1602_PIN & 0xF0;
	clrb(LCD1602_PORT, LCD1602_PIN_EN); //disable
	LNib>>=4;
	return (HNib|LNib);
}

void Write2Nib(uint8_t chr)
{
	uint8_t HNib, LNib, temp_data;
	temp_data=LCD1602_PORT & 0x0F; //doc 4 bit thap cua LCD1602_PORT de mask,

	HNib=chr & 0xF0;
	LNib=(chr<<4) & 0xF0;

	LCD1602_PORT =(HNib |temp_data);
	setb(LCD1602_PORT,LCD1602_PIN_EN); //enable
	clrb(LCD1602_PORT,LCD1602_PIN_EN); //disable

	LCD1602_PORT =(LNib|temp_data);
	setb(LCD1602_PORT,LCD1602_PIN_EN); //enable
	clrb(LCD1602_PORT,LCD1602_PIN_EN); //disable
}

void wait_LCD()
{
	_delay_ms(1);
}

void LCD1602_Config()
{
	LCD1602_DDR = 0xFF;
	setb(LCD1602_DDR,4);
	setb(LCD1602_DDR,5);
	setb(LCD1602_DDR,6);
	setb(LCD1602_DDR,7);
	//Function set------------------------------------------------------------------------------
	clrb(LCD1602_PORT,LCD1602_PIN_RS);   // the following data is COMMAND
	
	clrb(LCD1602_PORT, LCD1602_PIN_EN);
	
	setb(LCD1602_PORT,LCD1602_PIN_EN); //enable
	setb(LCD1602_PORT, 5);
	clrb(LCD1602_PORT,LCD1602_PIN_EN); //disable
	wait_LCD();
	Write2Nib(0x28);//4 bit mode, 2 line, 5x8 font
	wait_LCD();
	
	//Display control-------------------------------------------------------------------------
	clrb(LCD1602_PORT,LCD1602_PIN_RS); // the following data is COMMAND
	
	Write2Nib(0x0C);
	//Write2Nib(0x0E);-------------co con tro
	wait_LCD();
	
	//Entry mode set------------------------------------------------------------------------
	clrb(LCD1602_PORT,LCD1602_PIN_RS); // the following data is COMMAND
	
	Write2Nib(0x06);
	wait_LCD();
	
}

void LCD1602_Home()
{
	clrb(LCD1602_PORT,LCD1602_PIN_RS); // the following data is COMMAND
	
	Write2Nib(0x02);
	wait_LCD();
	
}

void LCD1602_Move(uint8_t y,uint8_t x)
{
	uint8_t Ad;
	Ad=64*(y-1)+(x-1)+0x80; // t�nh m� l?nh
	clrb(LCD1602_PORT,LCD1602_PIN_RS); // the following data is COMMAND
	
	Write2Nib(Ad);
	wait_LCD();
	
}

void LCD1602_PutC(uint8_t chr)
{
	setb(LCD1602_PORT,LCD1602_PIN_RS); //this is a normal DATA
	
	Write2Nib(chr);
	wait_LCD();
	
}

void LCD1602_PutS(char* str)
{
	int i;
	for (i=0; str[i]!=0; i++) 
	LCD1602_PutC(str[i]);
}

void LCD1602_Num(int num)
{
	char dis[10];
	sprintf(dis, "%d", num);
	LCD1602_PutS(dis);
}

void LCD1602_Clear()
{ 
	LCD1602_Move(1,1);
	LCD1602_PutS("                ");
	LCD1602_Move(2,1);
	LCD1602_PutS("                ");
	LCD1602_Move(1,1);
}