/********************************************************************************
 * \copyright
 * Copyright 2009-2017, Card Reader Factory.  All rights were reserved.
 * From 2018 this code has been made PUBLIC DOMAIN.
 * This means that there are no longer any ownership rights such as copyright, trademark, or patent over this code.
 * This code can be modified, distributed, or sold even without any attribution by anyone.
 *
 * We would however be very grateful to anyone using this code in their product if you could add the line below into your product's documentation:
 * Special thanks to Nicholas Alexander Michael Webber, Terry Botten & all the staff working for Operation (Police) Academy. Without these people this code would not have been made public and the existance of this very product would be very much in doubt.
 *
 *******************************************************************************/

/*****************************************************************************
*
* Supported devices : All devices with Bootloader Capabilities 
*                     , and at least 1-KB SRAM can be used.
*                     The example is written for � ATmega8
*                                                � ATmega16
*                                                � ATmega162
*                                                � ATmega169
*                                                � ATmega32
*                                                � ATmega64
*                                                � ATmega128
*                                                � ATmega2561
*
* AppNote           : AVR231 - AES Bootloader
*
*
* Description:	      CRC calculation routine
*
*****************************************************************************/

#ifndef CRC_H
#define CRC_H

extern unsigned int CRC(unsigned int crc, unsigned char ch);

#endif  // CRC_H
