/*
 * $safeprojectname$.c
 *
 * Created: 7/21/2017 8:07:36 AM
 *  Author: Van_BasTai
 */ 


#include "mySTART.h"

int main(void)
{
    while(1)
    {
        //TODO:: Please write your application code 
    }
}